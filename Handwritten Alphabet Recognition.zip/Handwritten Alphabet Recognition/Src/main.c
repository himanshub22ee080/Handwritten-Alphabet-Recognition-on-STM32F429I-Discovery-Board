/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * ... (License info) ...
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "crc.h"
#include "dma2d.h"
#include "i2c.h"
#include "ltdc.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"
#include "fmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "stm32f429i_discovery.h"
#include "stm32f429i_discovery_ts.h" // Defines TS_StateTypeDef with TouchDetected, X, Y, Z
#include "stm32f429i_discovery_io.h"
#include "stm32f429i_discovery_lcd.h" // Includes fonts.h for Font24 etc.

#include "Log/lcd_log.h"
#include "TouchScreen/ts_capture.h"
#include "preprocess.h"
#include "char_pattern.h"
#include "gru_infer.h"
#include "test/tests_recognition.h"
#include "grunet_data.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
typedef enum {
  STATE_WAITING_FOR_START,
  STATE_DRAWING,
  STATE_SHOWING_RESULT
} AppState;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define Y_DISPLAY_OFFSET 20 // Define the offset used in the transformation

// --- Define START Button Area ---
#define BUTTON_TEXT_POS_Y   (BSP_LCD_GetYSize() * 3 / 4)      // Base Y position for button area
#define BUTTON_HEIGHT       40                              // Button visual height
#define BUTTON_WIDTH        120                             // Button visual width
// Touch coordinates (Y=0 is TOP) - Centered vertically around BUTTON_TEXT_POS_Y
#define BUTTON_START_Y_MIN  (BUTTON_TEXT_POS_Y - (BUTTON_HEIGHT / 2) -170)
#define BUTTON_START_Y_MAX  (BUTTON_START_Y_MIN + BUTTON_HEIGHT)
// Touch coordinates (X=0 is LEFT) - Centered horizontally
#define BUTTON_START_X_MIN  (BSP_LCD_GetXSize() / 2 - (BUTTON_WIDTH / 2))
#define BUTTON_START_X_MAX  (BUTTON_START_X_MIN + BUTTON_WIDTH)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
AppState current_state = STATE_WAITING_FOR_START; // Initial state
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
// Local function prototypes
void BSP_Init_Board(void);
void Test_Recognition(void);
void Display_Start_Screen(void);
void Display_Draw_Screen(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void BSP_Init_Board() {
    uint8_t ts_status = TS_OK;

	/* Initialize the LCD */
	BSP_LCD_Init();

	/* Initialize the LCD Layers */
	BSP_LCD_LayerDefaultInit(1, LCD_FRAME_BUFFER); // Foreground
	BSP_LCD_LayerDefaultInit(0, LCD_FRAME_BUFFER + BUFFER_OFFSET); // Background

	/* Configure Background Layer */
	BSP_LCD_SelectLayer(LCD_BACKGROUND_LAYER);
	// --- Set BLACK background, BLUE text ---
	BSP_LCD_Clear(LCD_COLOR_LIGHTMAGENTA );        // Black background
	BSP_LCD_SetTextColor(LCD_COLOR_BLUE);  // Blue text
	BSP_LCD_SetBackColor(LCD_COLOR_LIGHTMAGENTA ); // Black background
	BSP_LCD_SetFont(&Font12);

	/* Configure Foreground Layer (Active Layer) */
	BSP_LCD_SelectLayer(LCD_FOREGROUND_LAYER);
    // --- Set BLACK background, BLUE text ---
	BSP_LCD_Clear(LCD_COLOR_LIGHTMAGENTA );        // Black background
	BSP_LCD_SetTextColor(LCD_COLOR_BLUE);  // Default BLUE text/drawing color
	BSP_LCD_SetBackColor(LCD_COLOR_LIGHTMAGENTA ); // Black background
	BSP_LCD_SetFont(&Font16);             // Default font

	/* Initialize Logging */
	LCD_LOG_Init(); // Will use current layer settings (FG, Black BG, Blue Text)

	/* Initialize Touch Screen Controller */
	ts_status = BSP_TS_Init(BSP_LCD_GetXSize(), BSP_LCD_GetYSize());
	if (ts_status != TS_OK)
    {
        LCD_ErrLog("BSP TS Init failed!\n"); // Uses printf redirection
        Error_Handler(); // Error handler uses Red/White
    }

	/* Clear screen after setup */
	BSP_LCD_SelectLayer(LCD_FOREGROUND_LAYER);
	BSP_LCD_Clear(LCD_COLOR_BLACK); // Clear with new background color
}

void Display_Start_Screen(void) {
    BSP_LCD_Clear(LCD_COLOR_LIGHTMAGENTA ); // Black background
    BSP_LCD_SetFont(&Font20);       // Large font for title
    BSP_LCD_SetTextColor(LCD_COLOR_BLUE); // Blue text
    BSP_LCD_SetBackColor(LCD_COLOR_LIGHTMAGENTA ); // Black background

    BSP_LCD_DisplayStringAtLine(0, (uint8_t*) "Himanshu B22EE080");
    BSP_LCD_DisplayStringAtLine(1, (uint8_t*) "Dishit   B22CS082");
    BSP_LCD_DisplayStringAtLine(4, (uint8_t*) "   HANDWRITTEN");
    BSP_LCD_DisplayStringAtLine(5, (uint8_t*) "    ALPHABET");
    BSP_LCD_DisplayStringAtLine(6, (uint8_t*) "   RECOGNITION");



    // Draw "button" text
    BSP_LCD_SetFont(&Font20); // Font for button text
    BSP_LCD_SetTextColor(LCD_COLOR_BLUE);
    BSP_LCD_DisplayStringAt(0, BUTTON_TEXT_POS_Y - (Font20.Height / 2), (uint8_t*)"   START   ", CENTER_MODE);

    // --- Draw Rectangle Around Button ---
    BSP_LCD_SetTextColor(LCD_COLOR_RED); // Blue rectangle
    BSP_LCD_DrawRect(BUTTON_START_X_MIN, BUTTON_START_Y_MIN + 170, BUTTON_WIDTH, BUTTON_HEIGHT);

    BSP_LCD_SetFont(&Font16); // Switch back to default font
}

void Display_Draw_Screen(void) {
    BSP_LCD_Clear(LCD_COLOR_LIGHTMAGENTA); // Black background
    BSP_LCD_SetFont(&Font16);
    BSP_LCD_SetTextColor(LCD_COLOR_BLUE); // Blue text
    BSP_LCD_SetBackColor(LCD_COLOR_LIGHTMAGENTA); // Black background
    BSP_LCD_DisplayStringAtLine(1, (uint8_t*) "   Draw a character");
    BSP_LCD_DisplayStringAtLine(2, (uint8_t*) "      [a to z]");
    BSP_LCD_DisplayStringAtLine(3, (uint8_t*) "----------------------------");
    BSP_LCD_DisplayStringAtLine(18, (uint8_t*) "----------------------------");
    BSP_LCD_DisplayStringAtLine(19, (uint8_t*) "****************************");
}


void Test_Recognition() {
	ai_handle gru_handle = GRU_NetwokHandle();
	Test_Preprocess_CorrectSlant();
	Test_Preprocess_Normalize();
	Test_GRU(gru_handle);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  TS_StateTypeDef ts_state;
  TS_Capture_SaveTouchDef ts_save_status;
  uint32_t tick, last_touch = 0;
  uint16_t lcd_height;
  uint16_t touch_x, touch_y; // Raw touch coordinates

  float touches_x_data[PATTERN_SIZE];
  float touches_y_data[PATTERN_SIZE];
  CharPattern sample;
  sample.xcoords = touches_x_data;
  sample.ycoords = touches_y_data;
  sample.size = 0;

  CharPattern_PredictedInfo result_info;
  ai_error err = { AI_ERROR_NONE, AI_ERROR_CODE_NONE };
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();
  SystemClock_Config();

  /* Initialize Peripherals */
  MX_GPIO_Init();
  MX_DMA2D_Init();
  MX_FMC_Init();
  MX_I2C3_Init();
  MX_LTDC_Init();
  MX_SPI5_Init();
  MX_CRC_Init();

  /* USER CODE BEGIN 2 */
  BSP_Init_Board(); // Initializes LCD with Black BG, Blue Text/Draw

  lcd_height = BSP_LCD_GetYSize();

  // --- Initialize GRU Model ---
  err = GRU_Init();
  if (err.code != AI_ERROR_CODE_NONE) {
      LCD_ErrLog("GRU Init Error! T=%d C=%d\n", err.type, err.code);
      Error_Handler(); // Shows Red/White error screen
  }
  // GRU_LogNetworkInfo(); // Optional


  // --- Display Initial Screen ---
  current_state = STATE_WAITING_FOR_START; // Set initial state
  Display_Start_Screen();


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  BSP_TS_GetState(&ts_state);
	  tick = HAL_GetTick();

      // --- State Machine Logic ---
      switch (current_state)
      {
          case STATE_WAITING_FOR_START:
              if (ts_state.TouchDetected) {
                  touch_x = ts_state.X;
                  touch_y = ts_state.Y; // Use raw Y coordinate

                  // Check if touch is within button bounds (using raw Y)
                  if (touch_x >= BUTTON_START_X_MIN && touch_x <= BUTTON_START_X_MAX &&
                      touch_y >= BUTTON_START_Y_MIN && touch_y <= BUTTON_START_Y_MAX)
                  {
                      // --- Transition to Drawing State ---
                      current_state = STATE_DRAWING;
                      TS_Capture_Reset();
                      last_touch = tick;
                      Display_Draw_Screen();
                  }
                  HAL_Delay(100); // Debounce
              }
              break; // End of WAITING_FOR_START state


          case STATE_DRAWING:
              // Drawing color should be blue from BSP_Init_Board default
              if (ts_state.TouchDetected) {
                  uint16_t y_raw = ts_state.Y;
                  uint16_t y_display;

                  // Y-Transform calculation for drawing
                  if (y_raw + Y_DISPLAY_OFFSET >= lcd_height) {
                      y_display = 0;
                  } else {
                      y_display = lcd_height - y_raw - Y_DISPLAY_OFFSET;
                  }
                  // Pass modified state to save function
                  ts_state.Y = y_display;

                  ts_save_status = TS_Capture_SaveTouch(&ts_state);
                  if (ts_save_status == TS_CAPTURE_SAVED) {
                      TS_Capture_DrawLastStroke(); // Draws in Blue
                  }
                  last_touch = tick;

              } else if (TS_Capture_GetNumOfTouches() > 0 && (tick - last_touch > 1000)) {
                  // --- Timeout occurred: Process Drawing ---
                  uint32_t n_touches = TS_Capture_GetNumOfTouches();
                  if (n_touches > 2) {
                      Preprocess_MakePattern(TS_Capture_TouchesX, TS_Capture_TouchesY, n_touches, &sample);
                      err = GRU_Infer(&sample, &result_info);

                      BSP_LCD_Clear(LCD_COLOR_LIGHTMAGENTA ); // Black background
                      BSP_LCD_SetFont(&Font16);
                      BSP_LCD_SetTextColor(LCD_COLOR_BLUE); // Blue text
                      BSP_LCD_SetBackColor(LCD_COLOR_LIGHTMAGENTA ); // Black background

                      if(err.code != AI_ERROR_CODE_NONE) {
                           LCD_ErrLog("GRU Infer Error: T=%d C=%d\n", err.type, err.code);
                           BSP_LCD_DisplayStringAtLine(7, (uint8_t*)"Inference Error!"); // Blue text
                      } else {
                          // Display result - REQUIRES CharPattern_PrintResult TO WORK
                          CharPattern_PrintResult(&result_info); // Should use blue text
                      }
                      // Display prompt to continue
                      BSP_LCD_DisplayStringAtLine(9, (uint8_t*) "     Touch screen"); // Blue text
                      BSP_LCD_DisplayStringAtLine(10, (uint8_t*) "     to continue"); // Blue text
                      current_state = STATE_SHOWING_RESULT; // Transition

                  } else { // Not enough points
                      BSP_LCD_Clear(LCD_COLOR_LIGHTMAGENTA ); // Black background
                      BSP_LCD_SetFont(&Font16);
                      BSP_LCD_SetTextColor(LCD_COLOR_BLUE); // Blue text
                      BSP_LCD_SetBackColor(LCD_COLOR_LIGHTMAGENTA ); // Black background
                      BSP_LCD_DisplayStringAtLine(4, (uint8_t*) "      Draw again");
                      BSP_LCD_DisplayStringAtLine(5, (uint8_t*) "       Properly");
                      BSP_LCD_DisplayStringAtLine(6, (uint8_t*) "   Need more points");
                      BSP_LCD_DisplayStringAtLine(7, (uint8_t*) "     to classify");
                      // Stay in STATE_DRAWING, allow user to redraw
                  }
                  TS_Capture_Reset();
                  last_touch = tick;
              }
              break; // End of DRAWING state


          case STATE_SHOWING_RESULT:
              if (ts_state.TouchDetected) {
                  // --- Transition back to Drawing State ---
                  current_state = STATE_DRAWING;
                  TS_Capture_Reset();
                  last_touch = tick;
                  Display_Draw_Screen(); // Displays prompt on black bg
                  HAL_Delay(100); // Debounce
              }
              break; // End of SHOWING_RESULT state

      } // End switch(current_state)

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* SystemClock_Config() definition */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  if (HAL_PWREx_EnableOverDrive() != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK) { Error_Handler(); }

  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LTDC;
  PeriphClkInitStruct.PLLSAI.PLLSAIN = 50;
  PeriphClkInitStruct.PLLSAI.PLLSAIR = 2;
  PeriphClkInitStruct.PLLSAIDivR = RCC_PLLSAIDIVR_2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK) { Error_Handler(); }
}

/* HAL_TIM_PeriodElapsedCallback() definition */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
}

/* Error_Handler() definition */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_14, GPIO_PIN_SET); // Red LED on PG14
  // Keep error screen Red/White for visibility
  BSP_LCD_SelectLayer(LCD_FOREGROUND_LAYER);
  BSP_LCD_SetBackColor(LCD_COLOR_RED);
  BSP_LCD_SetTextColor(LCD_COLOR_WHITE);
  BSP_LCD_Clear(LCD_COLOR_RED);
  BSP_LCD_SetFont(&Font16);
  BSP_LCD_DisplayStringAtLine(5, (uint8_t*)"   FATAL ERROR   ");
  while (1);
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/* assert_failed() definition */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
    LCD_ErrLog("Assert Failed: %s L%lu\n", file, line); // Prints via printf redirection
    Error_Handler(); // Shows Red/White screen
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
